#!/bin/sh
# Programa   : BACKUP VIA RMAN
# Funcao     : Este script executa o backup online do Oracle
# Versão     : 1.2
#
###############################################################################

Inicio ()
{

  # Variaveis de ambiente

  . /home/${USER}/.bash_profile           # Variaveis def. no profile do oracle
  unset ORACLE_SID
  export ORACLE_SID="${DBNAME}"
  export AUX_DBNAME="$( echo ${DBNAME} | tr 'a-z' 'A-Z')"
  DirBase=/opt/prd12/backup/
  DirScripts=${DirBase}/scripts
  DirLog=${DirBase}/log
  DirTmp=${DirBase}/tmp
  ArqTmp=${DirTmp}/arqlog_${programa}_$$.tmp
  ArqParametro=${DirTmp}/${programa}_parametro_$$.log        # Arquivo de parametros
  ArqAux=${DirTmp}/${programa}_Aux_$$.log        # Arquivo temporario auxiliar
  ArqLogErros=${DirTmp}/${programa}_erros_$$.log # Arquivo de log dos Erros
  Arq_Lock_Completo="${DirTmp}/backuporacle_${AUX_DBNAME}.lock"
  Arq_Lock_Archive="${DirTmp}/backuparchive_${AUX_DBNAME}.lock"
  backup_passwd=manager
  cliente=PRD12
  STATUS=OK
  StepCount=0
  if [  "${programa}" = "bkparchives" ]
  then
    ArqLogProcesso="${DirLog}/${AUX_DBNAME}_${programa}_`date '+%Y%m%d'`.log"
  else
    ArqLogProcesso="${DirLog}/${AUX_DBNAME}_${programa}_`date '+%Y%m%d%H%M%S'`.log"
  fi
  RMAN_CMD="$ORACLE_HOME/bin/rman nocatalog target sys/${backup_passwd}"
  TmpTime=30
  LogTime=30
  Envia_Mail_Bkp_Arch=N
  
  ########################################################
  # Variaveis de checagem de Backup visando a Monitoracao#
  ########################################################
  DirChkBkp="${DirBase}/log"                # Diretorio de Checagem dos Backups
  ArqBkpConcluido="$DirChkBkp/Bkp_${AUX_DBNAME}_Concluido" # Arquivo de Backup Concluido
  ArqBkpUltExec="$DirChkBkp/Bkp_${AUX_DBNAME}_Ultima_Exec" # Arquivo da Ultima Execucao Backup
  ArqBkpAndamento="$DirChkBkp/Bkp_${AUX_DBNAME}_Andamento" # Arquivo de Backup em Andamento

  ######################################################
  # Variaveis para o Export do Catalogo do RMAN        #
  ######################################################
  Backup_Rman=N
  Dir_Dmp_Rman="${DirBase}/rman/dmp"
  Dir_Log_Rman="${DirBase}/rman/log"
  Arq_Dmp_Rman="$Dir_Dmp_Rman/Exp_Rman_Catalog_`date '+%Y%m%d'`_`date '+%H%M'`.dmp"
  Arq_Log_Rman="$Dir_Log_Rman/Exp_Rman_Catalog_`date '+%Y%m%d'`_`date '+%H%M'`.log"
  Rman_User="rman"
  Rman_Passwd="rman"
  Rman_Base="case"
  Rman_Dmp_Time=30
  Rman_Log_Time=30

  #####################################
  # Inicializa endereco de EMAIL ERRO #
  #####################################
  for i in `grep -v "^#" ${DirBase}/mail/endereco_email_erro.lst`
  do
    email_destino_erro="$email_destino_erro $i"
  done

  ####################################
  # Inicializa endereco de EMAIL LOG #
  ####################################
  for i in `grep -v "^#" ${DirBase}/mail/endereco_email_log.lst`
  do
    email_destino_log="$email_destino_log $i"
  done
}

#Grava no arquivo de logs qual o passo que esta sendo executado e quais as instrucoes
Display ()
{
  StepCount="`expr $StepCount + 1`"

  echo "[ $StepCount ] `date '+%d/%m/%Y %T'` $*" >> $ArqLogProcesso
}

#Inicializa os arquivos de controle da monitoracao
Inicio_Control_Monitoracao ()
{
  #Inicio Alteracoes - Arquivos de Controle Monitoracao
  
  #Verifica se existe o Arquivo Backup Concluido
  [ -f $ArqBkpConcluido ] && mv $ArqBkpConcluido $ArqBkpUltExec
  
  #Grava a data/hora do inicio do backup
  echo "data `date '+%s'`" > $ArqBkpAndamento
  
  #Grava o ID do Processo de Backup
  echo "processo $$" >> $ArqBkpAndamento
  
  # Fim Inclusao nos arquivos de controle monitoracao
}

#Finaliza os arquivos de controle da monitoracao, informando que backup foi concluido
Fim_Control_Monitoracao ()
{
  # Informa que terminou o Backup e grava a Data final de execucao #
  
  #Remove o arquivo de backup em andamento
  rm -f $ArqBkpAndamento
  
  #Grava no arquivo de Backup Concluido a data/hora de conclusão
  echo "`date '+%s'`" > $ArqBkpConcluido
}

# Executa backup Full do banco
BackupFullDatabase ()
{

  #limpa arquivo de log temporario
  cat /dev/null > ${ArqTmp}

  Display "Inciando backup Full do banco de dados"

  $RMAN_CMD cmdfile="${DirScripts}/bkp_db_full.rman" msglog=${ArqTmp} 2>&1

  if [ "$?" != "0" ]
  then
    STATUS=ERRO
    Display "ERRO - Backup Full do Banco"
    cat $ArqTmp >> $ArqLogProcesso
    echo "`date '+%d/%m/%Y %T'` -> Erro no backup full do banco" >> $ArqLogErros
    return 1
  else
    Display "OK - ${programa}"
  fi

  cat $ArqTmp >> $ArqLogProcesso

  Display "Concluido Backup full do banco" 

}

# Executa backup dos Archives
BackupDatabaseArchives ()
{
  # Verifica se existe o arquivo de Lock
  if [ -f $Arq_Lock_Archive ]
  then
    # Recupera o ID do processo
     PID="`cat $Arq_Lock_Archive`"

    # Verifica se o processo existe no SO
     ps $PID > /dev/null 2>&1
   
    if [ "$?" = "0" ]
    then
      # O Processo do backup dos archives existe no SO
      Display "Backup dos archives já está executando.."
            Display "Concluido Backup dos archives"

    else
      # O processo no SO nao existe mais, remover o arquivo de lock dos archives
      Display "Arquivo de lock encontrado, mas processo do SO não está executando, removendo arquivo de lock"
      rm -f $Arq_Lock_Archive

      # Verifica se o arquivo de lock foi removido com sucesso
      if [ "$?" = "0" ]
      then
        Display "Sucesso na remoção do arquivo de lock dos archives"
            else
        STATUS="ERRO"
        Display "Erro na remoção do arquivo de lock dos archives"
            fi
                          
    fi
        fi

  if [ ! -f $Arq_Lock_Archive ] 
  then 
    
    #Cria arquivo de Lock com o ID do processo
    echo $$ > $Arq_Lock_Archive
  
    #limpa arquivo de log temporario
    cat /dev/null > ${ArqTmp}

    Display "Inciando backup dos archives"

    $RMAN_CMD cmdfile="${DirScripts}/bkp_archives.rman" msglog=${ArqTmp} 2>&1

    if [ "$?" != "0" ]
    then
      STATUS=ERRO
      Display "ERRO - Backup dos archives"
      cat $ArqTmp >> $ArqLogProcesso
      echo "`date '+%d/%m/%Y %T'` -> Erro no backup dos archives" >> $ArqLogErros
      return 1
    else
      Display "OK - ${programa}"
    fi

    cat $ArqTmp >> $ArqLogProcesso

    Display "Concluido Backup dos archives"
    
    #Apaga arquivo de lock
    rm -f $Arq_Lock_Archive
  fi

}

# Executa remocao dos backups obsoletos
DeleteObsolete ()
{

  #limpa arquivo de log temporario
  cat /dev/null > ${ArqTmp}
  
  Display "Iniciando Remocao dos Backups Obsoletos"

  $RMAN_CMD cmdfile="${DirScripts}/delete_obs.rman" msglog=${ArqTmp} 2>&1

  if [ "$?" != "0" ]
  then
    STATUS=ERRO
    Display "ERRO - Remocao dos Backup's Obsoletos"
    cat $ArqTmp >> $ArqLogProcesso
    echo "`date '+%d/%m/%Y %T'` -> Erro na Remocao dos Backup's Obsoletos" >> $ArqLogErros
    return 1
  else
    Display "OK - ${programa}"
  fi

  cat $ArqTmp >> $ArqLogProcesso

  Display "Concluido Remocao dos Backups Obsoletos"

}


# Executa backup Incremental do banco de dados do banco - Level 0
BackupIncLevel0 ()
{
  #limpa arquivo de log temporario
  cat /dev/null > ${ArqTmp}

  Display "Inciando backup Incremental do banco de dados"

  $RMAN_CMD cmdfile="${DirScripts}/bkp_db_incr_level0.rman" log=${ArqTmp} 2>&1 

  if [ "$?" != "0" ]
  then
    STATUS=ERRO
    Display "ERRO - Backup Incremental do Banco"
    cat $ArqTmp >> $ArqLogProcesso
    echo "`date '+%d/%m/%Y %T'` -> Erro no backup Incremantal do banco" >> $ArqLogErros
    return 1
  else
    Display "OK - ${programa}"
  fi

  cat $ArqTmp >> $ArqLogProcesso

  Display "Concluido Backup Incremental do banco"

}

# Executa backup Incremental do banco de dados do banco - Level 1 Normal
BackupIncLevel1 ()
{
  #limpa arquivo de log temporario
  cat /dev/null > ${ArqTmp}

  Display "Inciando backup Incremental do banco de dados"

  $RMAN_CMD cmdfile="${DirScripts}/bkp_db_incr_level1.rman" log=${ArqTmp} 2>&1

  if [ "$?" != "0" ]
  then
    STATUS=ERRO
    Display "ERRO - Backup Incremental do Banco"
    cat $ArqTmp >> $ArqLogProcesso
    echo "`date '+%d/%m/%Y %T'` -> Erro no backup Incremantal do banco" >> $ArqLogErros
    return 1
  else
    Display "OK - ${programa}"
  fi

  cat $ArqTmp >> $ArqLogProcesso

  Display "Concluido Backup Incremental do banco"

}

# Executa backup Incremental do banco de dados do banco - Level 1 Cumulativo
BackupIncLevel1C ()
{
  #limpa arquivo de log temporario
  cat /dev/null > ${ArqTmp}

  Display "Inciando backup Incremental do banco de dados"

  $RMAN_CMD cmdfile="${DirScripts}/bkp_db_incr_level1c.rman" log=${ArqTmp} 2>&1

  if [ "$?" != "0" ]
  then
    STATUS=ERRO
    Display "ERRO - Backup Incremental do Banco"
    cat $ArqTmp >> $ArqLogProcesso
    echo "`date '+%d/%m/%Y %T'` -> Erro no backup Incremantal do banco" >> $ArqLogErros
    return 1
  else
    Display "OK - ${programa}"
  fi

  cat $ArqTmp >> $ArqLogProcesso

  Display "Concluido Backup Incremental do banco"

}

# Executa export do catalogo do rman
ExpRmanCatalog ()
{

  if [ "$Backup_Rman" = "Y" ]
  then 
    #limpa arquivo de log temporario
    cat /dev/null > ${ArqTmp}

    Display "Inciando export do Catalogo do Rman"

    exp $Rman_User/$Rman_Passwd@$Rman_Base file=$Arq_Dmp_Rman log=$Arq_Log_Rman consistent=y buffer=8192000 1>>$ArqTmp 2>>$ArqTmp

    if [ "$?" != "0" ]
    then
      STATUS=ERRO
      Display "ERRO - Export do Catalogo do Rman"
      cat $ArqTmp >> $ArqLogProcesso
      echo "`date '+%d/%m/%Y %T'` -> Erro no export do catalogo do Rman" >> $ArqLogErros
      return 1
    else
      find $Dir_Dmp_Rman -mtime +$Rman_Dmp_Time -print -exec rm -f {} \; > /dev/null 2>&1
      find $Dir_Log_Rman -mtime +$Rman_Log_Time -print -exec rm -f {} \; > /dev/null 2>&1
      gzip $Arq_Dmp_Rman
      Display "OK - ${programa}"
    fi

    cat $ArqTmp >> $ArqLogProcesso

    Display "Fim export do Catalogo do Rman"
  fi
}

#Funcao para enviar email com o arquivo de logs
Envia_Email ()
{
  if [ "$STATUS" = "OK" ]
  then
    var=$email_destino_log
  else
    var=$email_destino_erro
  fi
  if [  "${programa}" != "bkparchives"  -o "$Envia_Mail_Bkp_Arch" != "N"  ]
  then
    mutt -a $ArqLogProcesso -s "$cliente-SID($ORACLE_SID)- Status do Backup ${programa}: $STATUS" -b $var < /dev/null
  fi
}

#Funcao que verifica se arquivo de lock ainda existe
Lock_Check () 
{
  if [ -f $1 ]
  then
    STATUS=ERRO
    Display "ERRO - Lock $1 do programa $programa encontrado!"
    # Enviar email do log do processo
    Envia_Email
    exit 0
  fi
  touch $1
}


##################################################
# Inicio Bloco Principal  - Controle de Processo #
##################################################
if [ "$#" -eq "2" ] || [ "$#" -eq "3" ]
then
  export DBNAME="$1"
  
  #Ser for backup full
  case $2 in

    'full')

      #Seta variavel bkpfull da base
      programa=bkpfulloracle

      # (0) Inicializa variaveis de ambiente
      Inicio

      # (1) Verifica existencia de lock
      Lock_Check $Arq_Lock_Completo
      
      # (2) Inicializa variaveis de monitoracao
      Inicio_Control_Monitoracao

      Display "Inicio Backup Full Oracle"

      # (3) Executa backup full do banco
      BackupFullDatabase

      Display  "Inicio Backup dos Archives"

      # (4) Executa backup archives do banco
      BackupDatabaseArchives
      
      Display  "Fim Backup dos Archives"

      # (5) Executa remocao dos obsoletos
      DeleteObsolete

      # (6) Executa export da base de RMAN
      ExpRmanCatalog

      # (7) Finaliza controle da monitoracao
      Fim_Control_Monitoracao

      Display  "Fim Backup Full Oracle"

      # Remove arquivo de Lock
      rm -f $Arq_Lock_Completo

    ;;

    #Ser for backup Incremental
    'incremental') 
      
      #Ser for backup Incremental com level 0
      case $3 in 
      'level0')

        #Seta variavel bkpfull da base
        programa=bkpinclevel0

        # (0) Inicializa variaveis de ambiente
        Inicio

        # (1) Verifica existencia de lock
        Lock_Check $Arq_Lock_Completo

        # (2) Inicializa variaveis de monitoracao
        Inicio_Control_Monitoracao

        Display  "Inicio Backup Incremental Level 0"

        # (3) Executa backup Level0 do banco
        BackupIncLevel0

        Display  "Inicio Backup dos Archives"

        # (4) Executa backup archives do banco
        BackupDatabaseArchives
      
        Display  "Fim Backup dos Archives"

        # (5) Executa remocao dos obsoletos
        DeleteObsolete

        # (6) Executa export da base de RMAN
        ExpRmanCatalog

        # (7) Finaliza controle da monitoracao
        Fim_Control_Monitoracao
        
        Display  "Fim Backup Incremental Level 0"

        # Remove arquivo de Lock
        rm -f $Arq_Lock_Completo

        ;;
        
      #Ser for backup Incremental com level 1
      'level1')

        #Seta variavel bkpfull da base
        programa=bkpinclevel1

        # (0) Inicializa variaveis de ambiente
        Inicio

        # (1) Verifica existencia de lock
        Lock_Check $Arq_Lock_Completo

        # (2) Inicializa variaveis de monitoracao
        Inicio_Control_Monitoracao

        Display  "Inicio Backup Incremental Level 1"

        # (3) Executa backup Level1 do banco
        BackupIncLevel1

        Display  "Inicio Backup dos Archives"

        # (4) Executa backup archives do banco
        BackupDatabaseArchives
      
        Display  "Fim Backup dos Archives"

        # (5) Executa remocao dos obsoletos
        DeleteObsolete

        # (6) Executa export da base de RMAN
        ExpRmanCatalog

        # (7) Finaliza controle da monitoracao
        Fim_Control_Monitoracao

        Display  "Fim Backup Incremental Level 1" 

        # Remove arquivo de Lock
        rm -f $Arq_Lock_Completo

        ;;

      #Ser for backup Incremental com level 1 cumulativo
      'level1c')

        #Seta variavel bkpfull da base
        programa=bkpinclevel1c

        # (0) Inicializa variaveis de ambiente
        Inicio

        # (1) Verifica existencia de lock
        Lock_Check $Arq_Lock_Completo

        # (2) Inicializa variaveis de monitoracao
        Inicio_Control_Monitoracao

        Display  "Inicio Backup Incremental Level 1 Cumulativo"

        # (3) Executa backup Level1 do banco
        BackupIncLevel1C

        Display  "Inicio Backup dos Archives"

        # (4) Executa backup archives do banco
        BackupDatabaseArchives
      
        Display  "Fim Backup dos Archives"
        
        # (5) Executa remocao dos obsoletos
        DeleteObsolete

        # (6) Executa export da base de RMAN
        ExpRmanCatalog

        # (7) Finaliza controle da monitoracao
        Fim_Control_Monitoracao

        Display  "Fim Backup Incremental Level 1 Cumulativo"

        # Remove arquivo de Lock
        rm -f $Arq_Lock_Completo

        ;;

      *)
        echo "usage: $0 ORACLE_SID incremental { level0 |level1 |level1c }"
        exit 0
        ;;

      esac

    ;;

    #Ser for backup dos archives
    'archive')

      #Seta variavel bkpfull da base
      programa=bkparchives

      # (0) Inicializa variaveis de ambiente
      Inicio

      Display  "Inicio Backup dos Archives"

      # (1) Executa backup archives do banco
      BackupDatabaseArchives

      Display  "Fim Backup dos Archives"

    ;;

    *)
      echo "usage: $0 ORACLE_SID { full | incremental { level0 | level1 | level1c } | archive }"
      exit 0
    ;;

  esac

else 
  echo "usage: $0 ORACLE_SID { full | incremental { level0 | level1 | level1c } | archive }"
  exit 0
fi


# Enviar email do log do processo
Envia_Email

####################
# LIMPEZA DOS LOGS #
####################

rm -f ${ArqTmp}

if [ -d $DirLog ]
then
   find $DirLog/*${programa}*.log -mtime +$LogTime -print -exec rm -f {} \; > /dev/null 2>&1
fi

if [ -d $DirTmp ]
then
   find $DirTmp/${programa}*.log -mtime +$TmpTime -print -exec rm -f {} \; > /dev/null 2>&1
fi
