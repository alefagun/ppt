#!/bin/sh

bkpserver="//rmdc/backup_rmdb"
src_dir=/backup
dest_dir=/mnt/backup/srv-moreira
logfile=bkp-srv-moreira.log

umount /mnt/backup
mount -t cifs -o username=backup,password=backupti#2004 $bkpserver /mnt/backup ; RC=$?

if test ${RC} -ne 0; then
        echo "`date "+%b %d %H:%M:%S"` Acessar computador remoto backup: ERROR" >> /backup/bkporacle/log/summary_log
else
        rsync -vcrlu --delete $src_dir $dest_dir > $dest_dir/$logfile ; RC=$?
        if test ${RC} -eq 0
        then
                echo "`date "+%b %d %H:%M:%S"` Copia backup: OK"  >> /backup/bkporacle/log/summary_log
        else
                echo "`date "+%b %d %H:%M:%S"` Copia backup (RC=$RC): ERROR" >> /backup/bkporacle/log/summary_log
        fi
fi
umount /mnt/backup